function zobrazMenu() {
	// Najst element menu
	var menu = document.querySelector('#mainHeader ul');

	// Zmenit display: 'toggle showhide'
	if (menu.style.display === 'block') {
		menu.style.display = 'none';
	} else {
		menu.style.display = 'block';
	}
}

// najst menu button
var menuButton = document.querySelector('.menu-icon');
// nastavit onclick
menuButton.onclick = zobrazMenu;
