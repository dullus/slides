
// Find current product
fetch('http://lukas.advertplus.sk/products_data.json')
.then(response => response.json())
.then(function(data) {
		console.log(data.data);
		var hash = window.location.hash;
		var productId = parseInt(hash.split('-')[1]);
		var allProducts = data.data;
		var product = allProducts.find(product => product.id === productId);

		document.querySelector('.product').innerHTML = render(product);

});

function render(product) {
	var { category, imagePath, name, price, size } = product;
	var imgPath = `img/products/${category}/${imagePath}`;
	return `<article>
		<div class="product-image"><img src="${imgPath}" alt="Obrazok produktu"></div>
		<div class="product-info">
			<header><h2>${name}</h2></header>
			<span>$${price}</span>
			<label for="velkost">Vyber si veľkosť</label>
				<select id="velkost" name="velkost">
					${renderOptions(size)}
				</select>
			<button onclick="addToCart(${price})">Pridat do kosika</button>
		</div>
	</article>`
}

function renderOptions(sizes) {
	return sizes.map(size => `<option label="${size}">${size}</option>`).join('');
}
