function zobrazMenu() {
	// Najst element menu
	var menu = document.querySelector('#mainHeader ul');

	// Zmenit display: 'toggle showhide'
	if (menu.style.display === 'block') {
		menu.style.display = '';
	} else {
		menu.style.display = 'block';
	}
}

// najst menu button
var menuButton = document.querySelector('.menu-icon');
var menu = document.querySelector('#mainHeader ul');

// nastavit onclick
menuButton.onclick = function() {
	toggle(menu);
};

function toggle(element) {
	// Zmenit display: 'toggle showhide'
	if (element.style.display === 'block') {
		element.style.display = '';
	} else {
		element.style.display = 'block';
	}
}
