
// console.log(productsData);
var allProducts;
// TODO: Michal| add to cart - calculation
fetch('http://lukas.advertplus.sk/products_data.json')
.then(
	function(response) {
		// console.log(response)
		return response.json()
	}
)
.then(function(data) {
		console.log(data.data);

		allProducts = data.data;
		render(allProducts);

});

function priceField(price, discount) {
	if (discount > 0) {
			var discountPrice = Math.ceil((price-price*discount) * 100) / 100;
			return `<div class="discountPrice">
					$${discountPrice}
				</div>
				<div class="originalPriceBox">
					<span class="originalPrice">
						$${price}
					</span>
					<span class="discountPercent">
						-${discount*100}%
					</span>
				</div>`;
	}
	return `<div class="price">$${price}</div>`;
}

function getDiscountedProducts () {
		var discountedProducts = allProducts.filter(product => (product.discount > 0));
		render(discountedProducts);
}
function getPopularProducts () {
		var popularProducts = allProducts.filter(product => (product.tags.indexOf('popular') >= 0));
		render(popularProducts);
}
// window.getDiscountedProducts = getDiscountedProducts;

function render (products) {
	var productViews = products.map(product => {
		var imgPath = `img/products/${product.category}/${product.imagePath}`;
		var discountPrice = product.price - product.price * product.discount;

		return `<a href="product.html#product-${product.id}">
			<article>
				<div class="img-wrapper">
					<img src="${imgPath}" alt="${product.name} photo preview" />
				</div>
				<aside>
					<header>
						${product.name}
					</header>
					<footer>
						${priceField(product.price, product.discount)}
					</footer>
				</aside>
			</article>
		</a>`
	});

	document.querySelector('.products').innerHTML = productViews.join(' ');
}
