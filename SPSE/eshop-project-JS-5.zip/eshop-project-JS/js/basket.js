var cart = localStorage.getItem('basket')

if (cart === null) {
	localStorage.setItem('basket', 0);
	renderBasket(0);
} else {
	renderBasket(cart)
}

function renderBasket(cart) {
	document.querySelector('.cart-price').innerHTML = '$' + cart;
}

function addToCart(price) {
	var cart = localStorage.getItem('basket')
	var added = parseFloat(cart) + price;
	localStorage.setItem('basket', added);
	renderBasket(added)
}
