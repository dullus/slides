productsData = [
		{
			"id": 1,
			"name": "Adidas n 5923",
			"description": "ash pink ftw white ftw white",
			"imagePath": "adidas-n-5923-w-ash-pink-ftw-white-ftw-white.jpg",
			"date": 1521624112577,
			"category": "damske",
			"tags": ["popular", "shiny"],
			"size": [36, 37, 39, 40],
			"price": 199,
			"discount": 0
		},
		{
			"id": 2,
			"name": "Adidas stan smith",
			"description": "crystal white crystal white trace orange",
			"imagePath": "adidas-stan-smith-cf-w-crystal-white-crystal-white-trace-orange.jpg",
			"date": 1521624175482,
			"category": "damske",
			"tags": ["outdoor"],
			"size": [36, 37, 40],
			"price": 79.90,
			"discount": 0
		},
		{
			"id": 3,
			"name": "Adidas campus",
			"description": "trace scarlet ftw white ftw white",
			"imagePath": "adidas-campus-trace-scarlet-ftw-white-ftw-white.jpg",
			"date": 1521624184241,
			"category": "panske",
			"tags": [],
			"size": [40, 41, 42, 43, 44],
			"price": 111.99,
			"discount": 0
		},
		{
			"id": 4,
			"name": "Adidas swift run",
			"description": "grey three core black medium grey heather",
			"imagePath": "adidas-swift-run-grey-three-core-black-medium-grey-heather.jpg",
			"date": 1521624196694,
			"category": "panske",
			"tags": ["popular", "outdoor"],
			"size": [40, 41, 42, 43],
			"price": 75.60,
			"discount": 0.18
		},
		{
			"id": 5,
			"name": "Adidas tubular",
			"description": "shadow maroon vapor grey ftw white",
			"imagePath": "adidas-tubular-shadow-maroon-vapor-grey-ftw-white.jpg",
			"date": 1521624207753,
			"category": "panske",
			"tags": ["shiny"],
			"size": [42, 43, 44],
			"price": 200,
			"discount": 0.25
		},
		{
			"id": 6,
			"name": "Converse one star",
			"description": "ox golf le fleur jade lime mint green egret",
			"imagePath": "converse-one-star-ox-golf-le-fleur-jade-lime-mint-green-egret.jpg",
			"date": 1521624216394,
			"category": "panske",
			"tags": ["popular"],
			"size": [40, 43, 44],
			"price": 138.50,
			"discount": 0
		}
	]
