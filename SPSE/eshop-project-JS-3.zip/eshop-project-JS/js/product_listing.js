
// console.log(productsData);

fetch('http://lukas.advertplus.sk/products_data.json')
.then(
	function(response) {
		// console.log(response)
		return response.json()
	}
)
.then(function(data) {
		console.log(data.data);

		var products = data.data;
		products.forEach(product => {
			console.log(product.name)
			console.log(product.imagePath)
			return product.price
		})

		var ceny = products.map(product => product.price)
		console.log(ceny)

		var imgs = products.map(product =>
			'img/products/' + product.category + '/' + product.imagePath
		)
		console.log(imgs)

		var imgTags = imgs.map(img => '<img src="' + img +'" alt="product" />');

		document.querySelector('.products').innerHTML = imgTags.join(' ')
})
//
//
// var fun = (product, index) => {
//
// }
//
// function fun(product, index) {
//
// }
