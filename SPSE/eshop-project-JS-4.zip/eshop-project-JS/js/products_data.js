productsData = [
		{
			"id": 1,
			"name": "Adidas n 5923",
			"description": "ash pink ftw white ftw white",
			"imagePath": "adidas-n-5923-w-ash-pink-ftw-white-ftw-white.jpg",
			"date": 1521624112577,
			"category": "damske",
			"tags": ["popular", "shiny"],
			"size": [36, 37, 39, 40],
			"price": 199,
			"discount": 0
		},
		{
			"id": 1,
			"name": "Adidas n 5923",
			"description": "ash pink ftw white ftw white",
			"imagePath": "adidas-n-5923-w-ash-pink-ftw-white-ftw-white.jpg",
			"date": 1521624112577,
			"category": "damske",
			"tags": ["popular", "shiny"],
			"size": [36, 37, 39, 40],
			"price": 199,
			"discount": 0
		},
	]
